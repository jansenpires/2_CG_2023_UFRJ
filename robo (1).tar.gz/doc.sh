jsdoc -d /Users/roma/html/cwdc/13-webgl/doc-hierarchy-partial Hierarchy.js ../teal_book/cuon-matrix.js ../teal_book/cuon-utils.js ../lib/simple-rotator.js 
